docker load < modelS.tar
docker-compose up